<footer class="main-footer">
  <div class="float-right d-none d-sm-inline">
    PCMS v1.0
  </div>
  <strong>&copy; 2025 <a href="#">Public Consultation System</a>.</strong> All rights reserved.
</footer>
